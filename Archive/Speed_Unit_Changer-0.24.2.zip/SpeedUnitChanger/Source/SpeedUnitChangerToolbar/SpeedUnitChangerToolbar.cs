﻿/* Copyright © 2013-2014, Eliseo Martín <lttito@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;
using UnityEngine;
using Toolbar;
using SpeedUnitChanger;

namespace SpeedUnitChangerToolbar
{
    [KSPAddon(KSPAddon.Startup.EveryScene, false)]
    public class SpeedUnitChangerToolbar : MonoBehaviour
    {
        IButton button;

        void Awake()
        {
            SpeedUnitChanger.SpeedUnitChanger.DebugMessage("On Awake");
            SpeedUnitChanger.SpeedUnitChanger.ToolBarEnabled = false;
            button = ToolbarManager.Instance.add("SpeedUnitChanger", "button");
            button.ToolTip = "Speed Unit Changer";
            button.OnClick += toggleChanger;
            button.Visibility = new GameScenesVisibility(GameScenes.FLIGHT);
            setTexture(SpeedUnitChanger.SpeedUnitChanger.ToolBarEnabled);
        }

        void setTexture(bool value)
        {
            SpeedUnitChanger.SpeedUnitChanger.DebugMessage("On set textures");
            if (value)
            {
                
                button.TexturePath = "SpeedUnitChanger/Textures/iconToolbar_active";
            }
            else
            {
                button.TexturePath = "SpeedUnitChanger/Textures/iconToolbar";
            }
        }

        void toggleChanger(ClickEvent evnt)
        {
            SpeedUnitChanger.SpeedUnitChanger.DebugMessage("toggle changer");
            bool enabled = !SpeedUnitChanger.SpeedUnitChanger.ToolBarEnabled;
            SpeedUnitChanger.SpeedUnitChanger.ToolBarEnabled = enabled;
            setTexture(enabled);
        }

        void OnDestroy()
        {
            button.Destroy();
        }
    }
}
