﻿/* Copyright © 2016, Eliseo Martín <lttito@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using System.Threading.Tasks;

namespace SpeedUnitChanger
{
    [KSPAddon(KSPAddon.Startup.Flight, false)]
    public class SpeedUnitChanger : MonoBehaviour
    {
        /// <summary>
        /// config file path
        /// </summary>
        private static readonly string CONFIG_FILE = KSPUtil.ApplicationRootPath + "GameData/SpeedUnitChanger/settings.dat";

        #region Constants
        /// <summary>
        /// Constant to indicate units are Meters per second
        /// </summary>
        private const int METERS_PER_SECOND = 0;

        /// <summary>
        /// Constant to indicate units are Kilometers per hour
        /// </summary>
        private const int KILOMETERS_PER_HOUR = 1;

        /// <summary>
        /// Constant to indicate units are Miles per hour
        /// </summary>
        private const int MILES_PER_HOUR = 2;

        /// <summary>
        /// Constant to indicate units are knots
        /// </summary>
        private const int KNOTS = 3;

        /// <summary>
        /// Constant to indicate units are feets per second
        /// </summary>
        private const int FEET_PER_SECOND = 4;

        /// <summary>
        /// Constant to indicate altitude units are meters
        /// </summary>
        private const int METERS = 0;

        /// <summary>
        /// Constant to indicate altitude units are kilometers
        /// </summary>
        private const int KILOMETERS = 1;

        /// <summary>
        /// Constant to indicate altitude units are miles
        /// </summary>
        private const int MILES = 2;

        /// <summary>
        /// Constant to indicate altitude units are nautical miles
        /// </summary>
        private const int NAUTICAL_MILES = 3;

        /// <summary>
        /// Constant to indicate altitude units are feet
        /// </summary>
        private const int FEET = 4;

        #endregion Constants

        /// <summary>
        /// Flag for toolbar
        /// </summary>
        public static bool ToolBarEnabled = false;

        /// <summary>
        /// App variables
        /// </summary>
        private string currentSpeed;
        private int winPosX;
        private int winPosY;
        private string currentUnit;
        private double altitude;
        private string altitudeText;
        private int currentSpeedIndication;
        private int currentAltitudeIndication;
        private bool showAltitude;
        private ConfigNode config;
        private Rect AltitudeWindow;
        private Rect ConfigurationWindow = new Rect(50, 50, 170, 180);
        private string[] content = new string[5];
        private string[] altitudeUnitNames = new string[5];

        /// <summary>
        /// Object contructor.
        /// </summary>
        public SpeedUnitChanger()
        {
            //DebugMessage("Object Construction");
        }

        /// <summary>
        /// Called when destroyed
        /// </summary>
        void OnDestroy()
        {
            //Nothing to Destroy
            SaveSettings();
        }

        /// <summary>
        /// Prints a message in the debug console
        /// </summary>
        /// <param name="text">text to print</param>
        public static void DebugMessage(string text)
        {
            print("Speed Unit Changer mod: " + text);
        }

        private void loadConfig()
        {
            try
            {
                config = ConfigNode.Load(CONFIG_FILE);
                int val = Convert.ToInt32(config.GetValue("unit"));
                bool altWin = Convert.ToBoolean(config.GetValue("alt"));
                int altWinX = Convert.ToInt32(config.GetValue("x"));
                int altWinY = Convert.ToInt32(config.GetValue("y"));
                int altunit = Convert.ToInt32(config.GetValue("altunit"));
                config = null;
                currentSpeedIndication = val;
                showAltitude = altWin;
                winPosX = altWinX;
                winPosY = altWinY;
                currentAltitudeIndication = altunit;
                //DebugMessage("Options loaded from file...");
            }
            catch (Exception ex)
            {
                //DebugMessage("Load default options...");
                currentSpeedIndication = METERS_PER_SECOND;
                showAltitude = false;
                winPosX = 50;
                winPosY = 50;
                currentAltitudeIndication = METERS;
            }
        }

        private void SaveSettings()
        {
            //DebugMessage("Saving config file...");
            ConfigNode savingNode = new ConfigNode();
            savingNode.AddValue("unit", currentSpeedIndication.ToString());
            savingNode.AddValue("alt", showAltitude.ToString());
            savingNode.AddValue("x", AltitudeWindow.x.ToString());
            savingNode.AddValue("y", AltitudeWindow.y.ToString());
            savingNode.AddValue("altunit", currentAltitudeIndication.ToString());
            savingNode.Save(CONFIG_FILE);
        }

        /// <summary>
        /// Called when plugin is loaded
        /// </summary>
        public void Awake()
        {
            //DebugMessage("Initializing");
            loadConfig();
            AltitudeWindow = new Rect(winPosX, winPosY, 100, 50);
            content[METERS_PER_SECOND] = "Meters per second (m/s)";
            content[KILOMETERS_PER_HOUR] = "Kilometers per hour (km/h)";
            content[MILES_PER_HOUR] = "Miles per hour (mph)";
            content[KNOTS] = "Knots (nmi/h)";
            content[FEET_PER_SECOND] = "Feet per second (ft/s)";
            altitudeUnitNames[METERS] = "Meters (m)";
            altitudeUnitNames[KILOMETERS] = "Kilometers (km)";
            altitudeUnitNames[MILES] = "Miles (mi)";
            altitudeUnitNames[NAUTICAL_MILES] = "Nautical miles (nmi)";
            altitudeUnitNames[FEET] = "Feet (ft)";
            RenderingManager.AddToPostDrawQueue(0, OnDraw);
        }

        /// <summary>
        /// Called when drawn
        /// </summary>
        public void OnDraw()
        {
            if (ToolBarEnabled)
            {
                ConfigurationWindow = GUILayout.Window(10, ConfigurationWindow, OnWindow, "Speed Unit Changer");
            }
            if (showAltitude)
            {
                AltitudeWindow = GUILayout.Window(11, AltitudeWindow, OnAltitudeWindow, "Altitude");
            }
        }

        /// <summary>
        /// Called when windowed
        /// </summary>
        /// <param name="windowId"></param>
        public void OnWindow(int windowId)
        {
            //DebugMessage("OnWindow");
            GUILayout.BeginVertical(GUILayout.Width(170f));
            showAltitude = GUILayout.Toggle(showAltitude, "Show Altitude");
            GUILayout.Label("Speed unit selection");
            currentSpeedIndication = GUILayout.SelectionGrid(currentSpeedIndication, content, 1);
            GUILayout.Label("Altitude unit selection");
            currentAltitudeIndication = GUILayout.SelectionGrid(currentAltitudeIndication, altitudeUnitNames, 1);
            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        public void OnAltitudeWindow(int windowId)
        {
            GUILayout.BeginHorizontal(GUILayout.Width(100f));
            GUILayout.Label(altitudeText);
            GUILayout.EndHorizontal();
            GUI.DragWindow();
        }

        public void LateUpdate()
        {
            UpdateSpeedValue();
            UpdateAltitudeValue();
        }

        private void UpdateSpeedValue()
        {
            if (currentSpeedIndication == KILOMETERS_PER_HOUR)
            {
                currentSpeed = (FlightGlobals.ship_srfSpeed * 3.6f).ToString("0.0");
                currentUnit = "km/h";
                if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Surface)
                {
                    currentSpeed = (FlightGlobals.ship_srfSpeed * 3.6f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Orbit)
                {
                    currentSpeed = (FlightGlobals.ship_obtSpeed * 3.6f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Target)
                {
                    currentSpeed = (FlightGlobals.ship_tgtSpeed * 3.6f).ToString("0.0");
                }
            }
            else if (currentSpeedIndication == MILES_PER_HOUR)
            {
                currentUnit = "mph";
                if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Surface)
                {
                    currentSpeed = (FlightGlobals.ship_srfSpeed * 2.23693629f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Orbit)
                {
                    currentSpeed = (FlightGlobals.ship_obtSpeed * 2.23693629f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Target)
                {
                    currentSpeed = (FlightGlobals.ship_tgtSpeed * 2.23693629f).ToString("0.0");
                }
            }
            else if (currentSpeedIndication == KNOTS)
            {
                currentUnit = "knots";
                if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Surface)
                {
                    currentSpeed = (FlightGlobals.ship_srfSpeed * 1.94384449f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Orbit)
                {
                    currentSpeed = (FlightGlobals.ship_obtSpeed * 1.94384449f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Target)
                {
                    currentSpeed = (FlightGlobals.ship_tgtSpeed * 1.94384449f).ToString("0.0");
                }
            }
            else if (currentSpeedIndication == FEET_PER_SECOND)
            {
                currentUnit = "ft/s";
                if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Surface)
                {
                    currentSpeed = (FlightGlobals.ship_srfSpeed * 3.2808399f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Orbit)
                {
                    currentSpeed = (FlightGlobals.ship_obtSpeed * 3.2808399f).ToString("0.0");
                }
                else if (FlightUIController.speedDisplayMode == FlightUIController.SpeedDisplayModes.Target)
                {
                    currentSpeed = (FlightGlobals.ship_tgtSpeed * 3.2808399f).ToString("0.0");
                }
            }
            if (currentSpeedIndication != METERS_PER_SECOND)
            {
                FlightUIController.fetch.speed.text = currentSpeed + " " + currentUnit;
            }
        }

        private void UpdateAltitudeValue()
        {
            if (currentAltitudeIndication == METERS)
            {
                altitude = FlightGlobals.ActiveVessel.altitude;
                altitudeText = altitude.ToString("0.000") + " m";
            }
            else if (currentAltitudeIndication == KILOMETERS)
            {
                altitude = FlightGlobals.ActiveVessel.altitude / 1000;
                altitudeText = altitude.ToString("0.000") + " km";
            }
            else if (currentAltitudeIndication == MILES_PER_HOUR)
            {
                altitude = FlightGlobals.ActiveVessel.altitude / 1609.344;
                altitudeText = altitude.ToString("0.000") + " mi";
            }
            else if (currentAltitudeIndication == NAUTICAL_MILES)
            {
                altitude = FlightGlobals.ActiveVessel.altitude / 1852;
                altitudeText = altitude.ToString("0.000") + " nmi";
            }
            else if (currentAltitudeIndication == FEET)
            {
                altitude = FlightGlobals.ActiveVessel.altitude * 3.2808399;
                altitudeText = altitude.ToString("0.000") + " ft";
            }
        }
    }
}
