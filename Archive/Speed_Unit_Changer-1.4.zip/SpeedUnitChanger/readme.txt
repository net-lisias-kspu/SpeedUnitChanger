Speed Unit Changer - Simple plugin to visualize current speed in different units.

Displays speed in different units in Navball.
Current speed units displayed:
-Meters per second
-Kilometers per hour
-Miles per hour
-Knots
-Feet per second

Now it also displays a window with the altitude depending on the unit selected for altitude:
- Meters
- Kilometers
- Miles
- Nautical miles
- feet

Changelog:
version 1.4.0: Update to use stock toolbar. Tested in 1.0.5
Version 1.3.0: Compatibility update for 0.24, Added unit selection for altitude.
Version 1.2.0: Added altitude window.
Version 1.1.0: 0.23.5 Compatibility.
Version 1.0.0: Initial release. Writes speed in navball. Writes orbital, surface or target speed.
Version 0.1.00: Initial version.